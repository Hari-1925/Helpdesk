const express = require("express");
const cors = require("cors");
require("./config/db");   // 👈 IMPORTANT PATH

const app = express();

app.use(cors());
app.use(express.json());
app.use("/uploads", express.static("backend/uploads"));

const ticketRoutes = require("./routes/ticketroute");
app.use("/api/tickets", ticketRoutes);

app.listen(5000, () => {
  console.log("Server running on port 5000");
});