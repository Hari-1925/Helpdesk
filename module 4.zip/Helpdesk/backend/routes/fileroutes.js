const express = require("express");
const multer = require("multer");
const File = require("../models/File");   // MongoDB model

const router = express.Router();

/* Multer storage config */
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "backend/uploads/");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  }
});

const upload = multer({ storage });

/* Upload route */
router.post("/upload", upload.single("file"), async (req, res) => {
  try {
    const { ticketId, description } = req.body;

    console.log("Ticket ID:", ticketId);
    console.log("Description:", description);
    console.log("File:", req.file);

    if (!req.file) {
      return res.status(400).json({ message: "File missing" });
    }

    // 🔥 SAVE TO MONGODB (THIS WAS MISSING)
    const newFile = new File({
      ticketId: ticketId,
      description: description,
      fileName: req.file.originalname,
      filePath: req.file.path
    });

    await newFile.save();

    res.json({
      message: "File uploaded successfully",
      fileName: req.file.originalname
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Upload failed" });
  }
});

module.exports = router;
