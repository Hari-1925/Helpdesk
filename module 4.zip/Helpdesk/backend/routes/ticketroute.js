const express = require("express");
const multer = require("multer");
const Ticket = require("../models/Ticket");

const router = express.Router();

// Storage location
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "backend/uploads");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  }
});

const upload = multer({ storage });

// Upload route
router.post("/upload", upload.single("file"), async (req, res) => {
  const ticket = new Ticket({
    title: req.body.title,
    description: req.body.description,
    fileName: req.file.originalname,
    filePath: req.file.path,
    uploadedBy: "User"
  });

  await ticket.save();
  res.json({ message: "File uploaded successfully" });
});

module.exports = router;