const mongoose = require("mongoose");

const ticketSchema = new mongoose.Schema({
  title: String,
  description: String,
  fileName: String,
  filePath: String,
  uploadedBy: String
});

module.exports = mongoose.model("Ticket", ticketSchema);