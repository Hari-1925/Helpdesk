const mongoose = require("mongoose");

const fileSchema = new mongoose.Schema({
  fileName: String,
  filePath: String,
  uploadedBy: String,
  ticketId: String
});

module.exports = mongoose.model("File", fileSchema);
