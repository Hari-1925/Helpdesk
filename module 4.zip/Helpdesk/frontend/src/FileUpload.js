import React, { useState } from "react";
import axios from "axios";

function FileUpload() {
  const [ticketId, setTicketId] = useState("");
  const [description, setDescription] = useState("");
  const [file, setFile] = useState(null);

  const uploadFile = async () => {
    if (!ticketId || !description || !file) {
      alert("All fields required");
      return;
    }

    const formData = new FormData();
    formData.append("ticketId", ticketId);
    formData.append("description", description);
    formData.append("file", file);

    try {
      await axios.post(
        "http://localhost:5000/api/files/upload",
        formData
      );
      alert("Upload successful ✅");
    } catch (err) {
      console.error(err);
      alert("Upload failed ❌");
    }
  };

  return (
    <div style={{ width: "350px", margin: "100px auto" }}>
      <h2>Helpdesk File Upload</h2>

      <input
        type="text"
        placeholder="Ticket ID"
        value={ticketId}
        onChange={(e) => setTicketId(e.target.value)}
      />
      <br /><br />

      <textarea
        placeholder="Description"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
      />
      <br /><br />

      <input
        type="file"
        onChange={(e) => setFile(e.target.files[0])}
      />
      <br /><br />

      <button onClick={uploadFile}>Upload</button>
    </div>
  );
}

export default FileUpload;
