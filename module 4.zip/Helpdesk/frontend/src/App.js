import FileUpload from "./FileUpload.js";

function App() {
  return (
    <div>
      <FileUpload />
    </div>
  );
}

export default App;
